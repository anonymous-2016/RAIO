screengrab.Clipboard = {
    putImgDataUrl : function(dataUrl, callbackWhenDone) {
        var image = window.content.document.createElement("img");
        image.setAttribute("style", "display: none");
        image.setAttribute("id", "screengrab_buffer");
        image.setAttribute("src", dataUrl);
        var body = window.content.document.getElementsByTagName("html")[0];
        body.appendChild(image);
        
        //setTimeout(this.copyImage(image, body, document, callbackWhenDone), 200);
        
        //SDM Alexandar's code cals it this way. 
        // I don't know the difference yet so I'll keep it.
        // copyImage returned a function which would seem to be an ok argument to settimeout
        // Is it really necessary to write code in this manner? Some private scope issue?
        setTimeout(function() { screengrab.Clipboard.copyImage(image, body, document, callbackWhenDone); }, 200);

    },
    
    copyImage : function(image, body, documenty, callbackWhenDone) {
//        return function () {
            documenty.popupNode = image;
            try {
                goDoCommand('cmd_copyImageContents');
            } catch (ex) {
                alert(ex);
            }
            body.removeChild(image);
            if (callbackWhenDone) {
                callbackWhenDone();
            }
//        };
    }
}

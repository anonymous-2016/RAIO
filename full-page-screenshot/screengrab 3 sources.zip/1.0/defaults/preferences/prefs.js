pref("extensions.screengrab@seanster.com.description", "chrome://screengrab/locale/screengrab.properties");
pref("extensions.screengrab.PrependDateStampInFilename", true); // 20121231_ prepended
pref("extensions.screengrab.PrependTimeStampInFilename", true); // 2356_ prepended
pref("extensions.screengrab.AppendDecUTCStampInFilename", false); // _1323625597702 Dec UTC milliseconds since 1970 epoch appended
pref("extensions.screengrab.AppendHexUTCStampInFilename", false); // AAAAAAAA Hex UTC seconds since 1970 epoch appended

pref("extensions.screengrab.ImageFormat", 2); // 0 = PNG, 1 = JPEG, 2 = JPG
pref("extensions.screengrab.ImageQuality", 85); // 75 is typical for jpeg, does not apply to PNG

pref("extensions.screengrab.ShowIconInStatusBar", true);
pref("extensions.screengrab.ShowInContextMenu", true);
pref("extensions.screengrab.ShowFileInDownloads", false);
pref("extensions.screengrab.UseBrowserDownloadDir", false);
pref("extensions.screengrab.ToolbarAddedOnce", false);

pref("extensions.screengrab.UseJavaIfAvailable", false);
pref("extensions.screengrab.JavaScrollWaitMs", 100);  // not exposed by options screen

pref("extensions.screengrab.EnableLogging", false);
pref("extensions.screengrab.LoggerFilename", "");  // win "C:\screengrab.log" linux "/tmp/screengrab.log"

pref("extensions.screengrab.NumberofGrabsTaken", 0);
pref("extensions.screengrab.Magic", false);

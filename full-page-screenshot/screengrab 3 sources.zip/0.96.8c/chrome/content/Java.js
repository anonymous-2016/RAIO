/**
 * @author 602527127
 */
screengrab.Java = {
	clForJar : new Object(),
	
	getStackTrace: function(e) {
		if (e.printStackTrace == undefined) {
			return e;
		}
        var baos = new java.io.ByteArrayOutputStream();
        var ps = new java.io.PrintStream(baos);
        e.printStackTrace(ps);
        ps.close();
        return baos.toString();
    },
    newArray: function(type) {
        var arrayLen = arguments.length - 1;
        var array = java.lang.reflect.Array.newInstance(java.lang.Class.forName(type), arrayLen);
        for (var i = 0; i < arrayLen; i++) {
            array[i] = arguments[i + 1];
        }
        return array;
    },

	isAvailable: function() {
return false;
		try {
			new java.lang.Integer(1);
		} catch (error) {
			return false;
		}
		var os = Packages.java.lang.System.getProperty("os.name");
		if (os == "Linux") {
			return true;
		}
		var version = Packages.java.lang.System.getProperty("java.version");
		if (version == "1.6.0_10" || version == "1.6.0_11") {
			return false;
		}
		return true;
	},

	capture: function(box) {
		screengrab.debug(box);
		var clazz = new Object();
		var baos = new java.io.ByteArrayOutputStream();
		var constructor = clazz.getConstructor(this.newArray("java.lang.Class", java.lang.Class.forName("java.io.OutputStream")));
		var b64os = constructor.newInstance(this.newArray("java.io.OutputStream", baos));
		
		var robot = new java.awt.Robot();
		robot.setAutoWaitForIdle(true);
		
		var image = robot.createScreenCapture(new java.awt.Rectangle(box.x, box.y, box.width, box.height));
		Packages.javax.imageio.ImageIO.write(image, "png", b64os);
		b64os.close();
		return "data:image/png;base64," + baos.toString();
	}
}
